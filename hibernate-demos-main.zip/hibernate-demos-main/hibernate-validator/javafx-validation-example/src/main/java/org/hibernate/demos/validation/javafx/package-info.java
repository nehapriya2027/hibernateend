/**
 *
 * This package contains several JavaFX related samples of JBV. The "sample1" sample is
 * quite small and only use some basic functionality. Each sample adds some additional
 * features.
 *
 * @author Hendrik Ebbers
 */
package org.hibernate.demos.validation.javafx;
