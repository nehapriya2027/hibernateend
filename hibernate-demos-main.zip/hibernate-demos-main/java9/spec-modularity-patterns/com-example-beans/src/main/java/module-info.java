module com.example.beans {
    requires fieldreader.spec;
    opens com.example.beans to fieldreader.spec;
}
