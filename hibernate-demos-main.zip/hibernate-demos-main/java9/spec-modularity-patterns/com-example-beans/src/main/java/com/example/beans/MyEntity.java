package com.example.beans;

public class MyEntity {

    private String name;

    public MyEntity(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}