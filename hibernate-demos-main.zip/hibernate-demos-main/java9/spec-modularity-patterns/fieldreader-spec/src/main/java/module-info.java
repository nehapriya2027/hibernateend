module fieldreader.spec {
    exports fieldreader.spec;
    exports fieldreader.spec.bootstrap;
    uses fieldreader.spec.bootstrap.FieldReaderProvider;
}
