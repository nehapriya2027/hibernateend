# hsearch-feature-examples

## Running the application

See the README inside the following three sub-directories, each with a different version of the application:

* `base`: basic ORM-based CRUD application.
* `search`: same as `base`, with the addition of Hibernate Search annotation and configuration.
* `search-advanced`: same as `search`, with more advanced examples.
