package org.hibernate.demos.hsearchfeatureexamples.model;

public enum FashionSeason {
	SPRING_SUMMER,
	FALL_WINTER
}
