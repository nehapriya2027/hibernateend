package org.hibernate.demos.hsearchfeatureexamples.model;

public enum TShirtSize {

	XS,
	S,
	M,
	L,
	XL,
	XXL,
	XXXL

}
