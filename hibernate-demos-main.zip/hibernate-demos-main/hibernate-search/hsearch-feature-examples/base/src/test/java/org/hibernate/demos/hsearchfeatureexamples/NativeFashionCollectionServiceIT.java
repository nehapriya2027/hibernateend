package org.hibernate.demos.hsearchfeatureexamples;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class NativeFashionCollectionServiceIT extends FashionCollectionServiceTest {

	// Execute the same tests but in native mode.
}