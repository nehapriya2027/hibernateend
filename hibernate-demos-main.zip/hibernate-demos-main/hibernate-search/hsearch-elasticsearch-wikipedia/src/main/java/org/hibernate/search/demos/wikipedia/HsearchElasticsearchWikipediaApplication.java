package org.hibernate.search.demos.wikipedia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HsearchElasticsearchWikipediaApplication {

	public static void main(String[] args) {
		SpringApplication.run(HsearchElasticsearchWikipediaApplication.class, args);
	}
}
