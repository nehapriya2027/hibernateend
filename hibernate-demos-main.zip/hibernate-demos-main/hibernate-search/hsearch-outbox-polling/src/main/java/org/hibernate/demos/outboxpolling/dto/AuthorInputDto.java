package org.hibernate.demos.outboxpolling.dto;

public record AuthorInputDto(String firstName, String lastName) {
}
