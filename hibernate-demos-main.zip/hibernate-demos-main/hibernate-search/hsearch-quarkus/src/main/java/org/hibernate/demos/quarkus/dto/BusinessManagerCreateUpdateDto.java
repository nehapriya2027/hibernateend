package org.hibernate.demos.quarkus.dto;

public class BusinessManagerCreateUpdateDto {

	public String name;

	public String email;

	public String phone;

}
