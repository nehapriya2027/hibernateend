package org.hibernate.demos.quarkus.dto;

public class BusinessManagerRetrieveDto {

	public long id;

	public String name;

	public String email;

	public String phone;

}
