package org.hibernate.demos.quarkus.dto;

public class ClientCreateUpdateDto {

	public String name;

}
