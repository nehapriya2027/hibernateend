package org.hibernate.demos.quarkus.dto;

public class ClientRetrieveDto {

	public long id;

	public String name;

	public BusinessManagerRetrieveDto assignedManager;

}
