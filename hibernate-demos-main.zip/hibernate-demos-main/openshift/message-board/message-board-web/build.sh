#!/usr/bin/env bash

#ng build --target production --output-path ../script/message-board-web
npm install
ng build --output-path ../script/message-board-web
