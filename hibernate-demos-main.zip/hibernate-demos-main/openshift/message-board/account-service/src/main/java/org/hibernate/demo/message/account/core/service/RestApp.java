package org.hibernate.demo.message.account.core.service;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath( "/" )
public class RestApp extends Application {
}
